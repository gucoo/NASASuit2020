﻿using UnityEngine.Events;

namespace HoloToolkit.Unity
{
    [System.Serializable]
    public class UnityEventFloat : UnityEvent<float>
    {
    }
}
