# GpuTiming
Use the GpuTiming component to meassure the time of your gpu calls.
Add the GpuTimingCamera component to the camera you want to track the total cost of.
Use GpuTiming.GetTime("Frame") to get the time (where "Frame" is the default tag used by GpuTimingCamera)

